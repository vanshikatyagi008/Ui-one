export interface CustomerDashboard {}
