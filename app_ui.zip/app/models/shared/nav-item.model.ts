export interface NavItem {}
