
# WishCart Enterprise UI

Integrated with:
- AuthController APIs
- RetailerController APIs
- JWT interceptor
- Route guards
- Angular routing
- Environment configs
- Product CRUD
- Profile APIs
- Enterprise component structure
