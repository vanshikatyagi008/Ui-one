
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({providedIn:'root'})
export class AuthService{
  api=environment.apiUrl+'/Auth';

  constructor(private http:HttpClient){}

  register(data:any){
    return this.http.post(`${this.api}/Register`,data);
  }

  login(data:any){
    return this.http.post(`${this.api}/Login`,data);
  }

  changePassword(data:any){
    return this.http.put(`${this.api}/ChangePass`,data);
  }

  getUser(){
    return this.http.get(`${this.api}/UserName`);
  }

  saveToken(token:string){
    localStorage.setItem('token',token);
  }

  getToken(){
    return localStorage.getItem('token');
  }

  logout(){
    localStorage.clear();
  }
}
