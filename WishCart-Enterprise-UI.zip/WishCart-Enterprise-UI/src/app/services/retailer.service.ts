
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({providedIn:'root'})
export class RetailerService{
 api=environment.apiUrl+'/Retailer';

 constructor(private http:HttpClient){}

 createProduct(data:FormData){
   return this.http.post(`${this.api}/create`,data);
 }

 getProducts(){
   return this.http.get(`${this.api}/Get`);
 }

 deleteProduct(id:number){
   return this.http.delete(`${this.api}/Delete/${id}`);
 }

 updateProduct(id:number,data:FormData){
   return this.http.put(`${this.api}/Update/${id}`,data);
 }

 profile(data:FormData){
   return this.http.put(`${this.api}/profile`,data);
 }

 viewProfile(){
   return this.http.get(`${this.api}/viewProfile`);
 }
}
