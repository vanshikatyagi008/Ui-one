
import { Component } from '@angular/core';

@Component({
 selector:'app-retailer-dashboard',
 standalone:true,
 templateUrl:'./retailer-dashboard.component.html',
 styleUrls:['./retailer-dashboard.component.css']
})
export class RetailerDashboardComponent{}
