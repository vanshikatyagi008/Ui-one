
export class ApiService{
baseUrl='https://localhost:5001/api';

login(data:any){}
register(data:any){}
getProducts(){}
}
