
import { Component } from '@angular/core';

@Component({
selector:'app-home',
standalone:true,
template:`
<section class="hero">
<div>
<h1>Discover Trending Products</h1>
<p>Beautiful shopping experience with modern animations.</p>
<button class="gradient-btn">Shop Now</button>
</div>

<img class="floating" src="https://dummyimage.com/500x350/dfefff/062b5b&text=WishCart"/>
</section>

<section class="products">
<div class="card glass" *ngFor="let p of products">
<h3>{{p.name}}</h3>
<p>{{p.category}}</p>
<button class="gradient-btn">View</button>
</div>
</section>
`,
styles:[`
.hero{
display:flex;
justify-content:space-around;
align-items:center;
padding:80px;
}

.hero h1{
font-size:56px;
color:#062b5b;
}

.products{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
gap:25px;
padding:40px;
}

.card{
padding:24px;
border-radius:24px;
text-align:center;
}
`]
})
export class HomeComponent{
products=[
{name:'Wireless Earbuds',category:'Electronics'},
{name:'Pink Hoodie',category:'Fashion'},
{name:'Gaming Mouse',category:'Accessories'},
{name:'Skincare Kit',category:'Beauty'}
]
}
