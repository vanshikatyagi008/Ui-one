
import { Component } from '@angular/core';

@Component({
selector:'app-register',
standalone:true,
template:`<div>Register Works</div>`
})
export class RegisterComponent{}
