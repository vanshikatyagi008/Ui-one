
import { Component } from '@angular/core';

@Component({
selector:'app-navbar',
standalone:true,
template:`
<nav class="nav">
<div class="logo">WishCart ✨</div>
<ul>
<li>Home</li>
<li>Products</li>
<li>Retailers</li>
<li>Contact</li>
</ul>
</nav>
`,
styles:[`
.nav{
display:flex;
justify-content:space-between;
padding:20px 40px;
background:#062b5b;
color:white;
position:sticky;
top:0;
z-index:100;
}
ul{
display:flex;
gap:30px;
list-style:none;
}
li{
cursor:pointer;
transition:0.3s;
}
li:hover{
color:#ffb6ff;
}
.logo{
font-size:24px;
font-weight:bold;
}
`]
})
export class NavbarComponent{}
