
import { Component } from '@angular/core';

@Component({
selector:'app-footer',
standalone:true,
template:`
<footer>
<h2>WishCart</h2>
<p>Modern E-Commerce Experience 💖</p>
</footer>
`,
styles:[`
footer{
background:#062b5b;
color:white;
text-align:center;
padding:30px;
margin-top:60px;
}
`]
})
export class FooterComponent{}
