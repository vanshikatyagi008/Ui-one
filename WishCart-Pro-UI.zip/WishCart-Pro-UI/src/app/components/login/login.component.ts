
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
selector:'app-login',
standalone:true,
imports:[FormsModule],
template:`
<section class="login-page">
<div class="banner floating">
<h1>Welcome Back 💙</h1>
<p>Your smart shopping universe starts here.</p>
</div>

<div class="login-card glass">
<h2>Login</h2>

<input type="email" placeholder="Email"/>
<input type="password" placeholder="Password"/>

<button class="gradient-btn">Login</button>

<p>Don't have an account? <span>Register</span></p>
</div>
</section>
`,
styles:[`
.login-page{
display:flex;
justify-content:center;
align-items:center;
gap:60px;
height:90vh;
padding:20px;
}

.banner{
width:40%;
}

.banner h1{
font-size:64px;
color:#062b5b;
}

.banner p{
font-size:20px;
}

.login-card{
width:360px;
padding:40px;
border-radius:24px;
display:flex;
flex-direction:column;
gap:18px;
}

input{
padding:14px;
border:none;
border-radius:12px;
}

span{
color:#ff4fa3;
font-weight:bold;
cursor:pointer;
}
`]
})
export class LoginComponent{}
