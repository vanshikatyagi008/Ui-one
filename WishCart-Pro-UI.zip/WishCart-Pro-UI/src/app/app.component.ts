
import { Component } from '@angular/core';

@Component({
  selector:'app-root',
  standalone:true,
  template:`
  <app-navbar></app-navbar>
  <app-login></app-login>
  <app-home></app-home>
  <app-footer></app-footer>
  `,
  imports:[]
})
export class AppComponent{}
