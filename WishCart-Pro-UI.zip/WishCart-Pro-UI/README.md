
# WishCart Pro UI

Modern Angular E-Commerce UI for WishCart backend.

## Features
- Animated login/register pages
- Baby blue + dark blue + pink gradient theme
- Responsive navbar
- Product cards
- Hero banner
- Dashboard-ready structure
- Angular standalone component architecture
- Easy API integration

## Run
```bash
npm install
ng serve
```
