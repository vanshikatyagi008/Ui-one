import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { TokenService } from '../services/token.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private tokenService: TokenService) {}

  canActivate(): boolean {
    // Use TokenService (reads 'auth_token') instead of bare localStorage key
    if (this.tokenService.hasToken() && !this.tokenService.isTokenExpired()) {
      return true;
    }
    this.tokenService.clearToken();
    this.router.navigate(['/login']);
    return false;
  }
}
